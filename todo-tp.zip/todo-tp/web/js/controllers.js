function TodoController($scope, $http) {
  
  $scope.todos = [];
  
  $scope.refreshTodos = function() {
  };  
    
  $scope.total = function() {
  };
  
  $scope.remaining = function() {
  };
  
  $scope.add = function() {
  };
  
  $scope.mark = function(todo) {
  };
  
  $scope.cleanup = function() {
  };
}